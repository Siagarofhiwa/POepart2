﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    public delegate void
        RecipeCaloriesExceededHandler(string recipeName, double totalCalories);

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string UnitOfMeasurements { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }

    public class Recipe
    {
        public List<Ingredient> Ingredients { get; set;}
        public List<Step> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void AddIngridient(string name, double quantity, string unitofmeasurement, int calories, string foodGroup)
        {
            Ingredient.Add(new Ingredient { Name = name, Quantity = quantity, UnitOfMeasurements = unitofmeasurement, Calories = Calories, FoodGroup = foodGroup });
        }

        public void DisplayRecipe(double scale = 1)
        {
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity * scale} {ingredient.UnitOfMeasurements} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }
        }
        public double CalculateTotalCalories()
        {
            double totalCalories = Ingredient.Sum(Ingredient => Ingredient.Calories * Ingredient.Quantity);
            return totalCalories;
        }

        public void NotifyCaloriesExceeded(RecipeCaloriesExceededHandler)
        {
            double totalCalories = CalculateTotalCalories();
            if(totalCalories >300)
            {
                handler?.Invoke(nameof, totalCalories);
            }
        }
    }

    class program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            double scale = 1;

            while (true)
            {
                Console.WriteLine("\n1. Enter recipe details ");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset quantities");
                Console.WriteLine("5. Clear data");
                Console.WriteLine("6. Exit");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter the number of ingredients:");
                        int numIngredients = Convert.ToInt32(Console.ReadLine());

                        for (int i = 0;i < numIngredients;i++)
                        {
                            Console.WriteLine($"Enter the name, quantity, and unit of neasurement for ingredient {i + 1}:");
                            string name = Console.ReadLine();
                            double quantity = Convert.ToDouble(Console.ReadLine());
                            string unit = Console.ReadLine();

                            recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, UnitOfMeasurements = unit });
                        }

                        Console.WriteLine("Enter the number of steps:");
                        int numSteps = Convert.ToInt32(Console.ReadLine());
                         
                        for (int i = 0; i < numSteps; i++)
                        {
                            Console.WriteLine($"Enter the description for step {i + 1}:");
                            string description = Console.ReadLine();

                            recipe.Steps.Add(new Step { Description = description });
                        }

                        break;

                    case 2:
                        recipe.DisplayRecipe(scale);
                        break;

                    case 3:
                        Console.WriteLine("Enter the scale factor (0.5, 2, or 3):");
                        scale = Convert.ToDouble(Console.ReadLine());

                        recipe.DisplayRecipe(scale);
                        break;

                    case 4:
                        scale = 1;
                        recipe.DisplayRecipe(scale);
                        break;

                    case 5:
                        recipe = new Recipe();
                        scale = 1;
                        break;

                    case 6:
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

static void AddRecipe(List<Recipe>recipes)
{
    Console.Write("Enter recipe name:");
    string name = Console.ReadLine();

    RecipeApp recipe = new RecipeApp(name);

    Console.Write("Enter the number of ingredient");

    int ingredientCount = int.Parse(Console.ReadLine());

    for (int 1 = 0; i < ingridientCount, i++)
    {
        Console.Write($"Ingredient{i + 1} name:");
        string ingredientName = Console.ReadLine();

        Console.Write($"Quantity of {ingredientName}");

        double quantity = double.Parse(Console.ReadLine());

        Console.Write($"Unit of masurement for {ingredientName}:");
        string unit = Console.ReadLine();

        Console.Write($"Calories per unit of {ingredientName}:");
        int calories = int.Parse(Console.ReadLine());

        Console.Write($"Food Group of {ingredientName}:");
        int calories = int.Parse(Console.ReadLine());

        recipe.AddIngredient(ingredientName, quantity, unitofmeasurement, calories, foodGroup);

    }

    Console.Write("Enter the number of steps:");
    int stepCount = int.Parse(Console.ReadLine());

    for (int i = 0; i < stepCount; i++)
    {
        Console.Write($"Step{i + 1}:");
        string description = Console.ReadLine();

        recipe.AddStep(description);
    }

    recipe.Add(recipe);

    recipe.NotifyCaloriesExceeded(OnRecipeCaloriesExceeded);
}

static void DisplayRecipeList(List<RecipeApp>recipes)
{
    if(recipes.Count==0)
    {
        Console.WriteLine("No recipes added yet.");
        return;
    }
    Console.WriteLine("Recipes:");
    foreach(var recipeApp in recipes.OrderBy(r=>r.Name))
    {
        Console.WriteLine(recipes.Name);
    }
}
static void SelectRecipeToDisplay(List<Recipe>recipes)
{
    Console.Write("Enter the name of the recipe to display:");
    string recipeName = Console.ReadLine();

    RecipeApp recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

    if(recipe! = null)
    {
        recipe.DisplayRecipe();
    }
    else
    {
        Console.WriteLine("Recipe not found");
    }
}

static void OnRecipeCaloriesExceeded(string recipeName, double totalCalories)
{
    Console.WriteLine($"warning: The total calories of recipe '{recipeName}' exceed 300. Total caloris: {totalCalories}");
}
    }
}
